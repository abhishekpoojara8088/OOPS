﻿using System;

namespace SealedClass
{
    class ParentCLS
    {
        public int P;
    }
    sealed class SealedCLS:ParentCLS
    {
        public int a;
    }

    //sealed class cannot be a parent class.
    //class ChildCLS : SealedCLS
    //{

    //}
    class Program
    {
        static void Main(string[] args)
        {
            SealedCLS SC = new SealedCLS();
            SC.a=100;
            Console.ReadKey();
        }
    }
}
