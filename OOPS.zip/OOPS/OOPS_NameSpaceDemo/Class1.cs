﻿using System;

namespace OOPS_NameSpaceDemo
{
    public class DemoCLS
    {
        public int a;
    }
}
