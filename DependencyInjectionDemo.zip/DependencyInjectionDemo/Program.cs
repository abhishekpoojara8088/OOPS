﻿using System;

namespace DependencyInjectionDemo
{
    interface IConstructorInjection
    {
        void DemoAbs(string str);
    }
    class ChildCLS1 : IConstructorInjection
    {
        void IConstructorInjection.DemoAbs(string str)
        {
            Console.WriteLine("DemoAbs Method Inside ChildCLS1 is called.");
            Console.WriteLine(str);
        }
    }

    class ChildCLS2 : IConstructorInjection
    {
        void IConstructorInjection.DemoAbs(string str)
        {
            Console.WriteLine("DemoAbs Method Inside ChildCLS2 is called.");
            Console.WriteLine(str);
        }

    }

    class ChildCLS3 : IConstructorInjection
    {
        void IConstructorInjection.DemoAbs(string str)
        {
            Console.WriteLine("DemoAbs Method Inside ChildCLS3 is called.");
            Console.WriteLine(str);
        }
    }

    class ConstructorInjectionClass
    {
        IConstructorInjection _ic = null;
        public ConstructorInjectionClass(IConstructorInjection _ic)
        {
            this._ic = _ic;
        }
        public void DemoInjectionFun(string str)
        {
            _ic.DemoAbs(str);
        }
    }

    class MethodInjectionClass
    {
        IConstructorInjection _ic = null;

        public void DemoInjectionFun(IConstructorInjection _ic, string str)
        {
            this._ic = _ic;
            _ic.DemoAbs(str);
        }
    }

    class PropertyInjectionClass
    {
        IConstructorInjection _ic = null;

        public void DemoInjectionFunWithProperty(IConstructorInjection _ic, string str)
        {
            this._ic = _ic;
            _ic.DemoAbs(str);
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            ConstructorInjectionClass CICObj = null;

            CICObj = new ConstructorInjectionClass(new ChildCLS1());
            CICObj.DemoInjectionFun("God is great..!!");

            CICObj= new ConstructorInjectionClass(new ChildCLS2());
            CICObj.DemoInjectionFun("God is great..!!");

            CICObj = new ConstructorInjectionClass(new ChildCLS3());
            CICObj.DemoInjectionFun("God is great..!!");

            MethodInjectionClass MICObj = new MethodInjectionClass();
            MICObj.DemoInjectionFun(new ChildCLS1(), "God is great..!!");
            MICObj.DemoInjectionFun(new ChildCLS2(), "God is great..!!");
            MICObj.DemoInjectionFun(new ChildCLS3(), "God is great..!!");

            //PropertyInjectionClass PICObj = new PropertyInjectionClass();
            //PICObj.DemoInjectionFunWithProperty(new ChildCLS1(), "God is great..!!");
            //PICObj.DemoInjectionFunWithProperty(new ChildCLS2(), "God is great..!!");
            //PICObj.DemoInjectionFunWithProperty(new ChildCLS3(), "God is great..!!");
            Console.ReadKey();
        }
    }
}
