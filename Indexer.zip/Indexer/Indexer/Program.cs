using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Indexer
{
    

    //Indexer: Array of this pointer in terms of properties, inside the class is called indexer.
    class DataStore<T>
    {
        //Array Declaration Without Size; Generic Array - No Data Type.
        private T[] store;
        
        public DataStore()
        {
            store = new T[10];
        }
        
        public DataStore(int length)
        {
            store = new T[length];
        }
        
        public T this[int index]
        {
            get
            {
                if (index < 0 && index >= store.Length)
                {
                    throw new IndexOutOfRangeException("Index out of range");
                }

                return store[index];
            }

            set
            {
                if (index < 0 || index >= store.Length)
                {
                    throw new IndexOutOfRangeException("Index out of range");
                }

                store[index] = value;
            }
        }

        public int Length
        {
            get
            {
                return store.Length;
            }
        }
    }

    class DataStore2<Type>
    {
        private Type[] ArrType;
        public DataStore2()
        {
            ArrType = new Type[10];
        }

        public DataStore2(int length)
        {
            ArrType = new Type[length];
        }

        public Type this[int index]
        {
            get {
                if (index < 0 && index >= ArrType.Length)
                    throw new IndexOutOfRangeException("Index out of range");

                return ArrType[index];
            }
            set {
                if (index < 0 && index >= ArrType.Length)
                    throw new IndexOutOfRangeException("Index out of range");

                ArrType[index] = value;
            }
        }
        public int Length
        {
            get
            {
                return ArrType.Length;
            }
        }
    }


    class ThisPointerDemo
    {
        public int a;
        public ThisPointerDemo()
        {
            this.a = 20;
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            ThisPointerDemo TPD = new ThisPointerDemo();
            Console.WriteLine(TPD.a);

            DataStore<int> grades = new DataStore<int>();
            grades[0] = 100;
            grades[1] = 25;
            grades[2] = 34;
            grades[3] = 42;
            grades[4] = 12;
            grades[5] = 18;
            grades[6] = 2;
            grades[7] = 95;
            grades[8] = 75;
            grades[9] = 53;

            for (int i = 0; i < grades.Length; i++)
                Console.WriteLine(grades[i]);

            DataStore<string> names = new DataStore<string>(5);
            names[0] = "Steve";
            names[1] = "Bill";
            names[2] = "James";
            names[3] = "Ram";
            names[4] = "Andy";
            

            for (int i = 0; i < names.Length; i++)
                Console.WriteLine(names[i]);


            DataStore2<float> FloatDemo = new DataStore2<float>(3);
            FloatDemo[0] = 10.10f;
            FloatDemo[1] = 20.20f;
            FloatDemo[2] = 30.30f;

            for (int i = 0; i < FloatDemo.Length; i++)
                Console.WriteLine(FloatDemo[i]);

            DataStore2<bool> BoolDemo = new DataStore2<bool>(4);
            BoolDemo[0] = true;
            BoolDemo[1] = false;
            BoolDemo[2] = true;
            BoolDemo[3] = true;

            for (int i = 0; i < BoolDemo.Length; i++)
                Console.WriteLine(BoolDemo[i]);


            Console.ReadKey();
        }
    }
}
