﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

//Delegate: Set of functions on a single bunch - function to address (pointer) concept.
delegate int Mathematics(int a,int b);

namespace Delegates
{
    class Program
    {
        public int AddNum(int N1, int N2)
        {
            int N = N1+N2;
            return N;
        }

        public int SubNum(int N1, int N2)
        {
            int N = N1-N2;
            return N;
        }

        public int MulNum(int N1, int N2)
        {
            int N = N1*N2;
            return N;
        }

        public int DivNum(int N1, int N2)
        {
            int N = N1/N2;
            return N;
        }

        static void Main(string[] args)
        {
            int Result = 0;
            
            Program P = new Program();
            
            Mathematics MAdd = new Mathematics(P.AddNum);
            Mathematics MSub = new Mathematics(P.SubNum);
            Mathematics MMul = new Mathematics(P.MulNum);
            Mathematics MDiv = new Mathematics(P.DivNum);

            Result = MAdd(10, 10);
            Console.WriteLine(Result);
            
            Result = MSub(10, 10);
            Console.WriteLine(Result);
            
            Result = MMul(10, 10);
            Console.WriteLine(Result);
            
            Result = MDiv(10, 10);
            Console.WriteLine(Result);
            
            Console.ReadKey();
        }
    }
}
