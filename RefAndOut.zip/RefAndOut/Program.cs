﻿using System;

namespace ResfAndOut
{
    class Program
    {
        public void Demo(int value)
        {
            value = 1;
        }
        public void Demo1(ref int value)
        {
            value = 1;
        }
        public void Demo2(out int value)
        {
            value = 1;
        }
        static void Main(string[] args)
        {
            int val;
            Program P = new Program();
           // P.Demo(val);
            //P.Demo1(ref val);
            P.Demo2(out val);
            Console.ReadKey();
        }
    }
}
